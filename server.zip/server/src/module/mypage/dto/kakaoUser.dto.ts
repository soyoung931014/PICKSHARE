export class KakaoUserDto {
  email: string;
}
