export class PasswordCheckDto {
  password: string;
}
