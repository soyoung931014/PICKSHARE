export class CreateCommentDto {
  text: string;
}
