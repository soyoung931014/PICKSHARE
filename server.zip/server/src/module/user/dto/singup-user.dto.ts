export class SignUpDto {

    email: string;
    nickname: string;
    password: string;

}